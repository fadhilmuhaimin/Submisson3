package com.tomjerry.ulangiapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.tomjerry.ulangiapp.dummy.DetailMovie;

public class DetailTv extends AppCompatActivity {
    public static final String EXTRA_INFO = "extra_info";
    TextView tvJudul,tvDeskripsi,tvInfo,tvRuntime,tvBudget,tvRevenue;
    ImageView imgPhoto,imgCollec;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_film);
        tvJudul = findViewById(R.id.title);
        tvDeskripsi = findViewById(R.id.textView8);
        tvInfo = findViewById(R.id.description);
        tvRuntime = findViewById(R.id.runtimee);
        tvBudget = findViewById(R.id.budget);
        tvRevenue = findViewById(R.id.revenuee);
        imgPhoto = findViewById(R.id.imageView);
        imgCollec = findViewById(R.id.collect);


        Tv info = getIntent().getParcelableExtra(EXTRA_INFO);
        String judul = info.getName();
        //  tvJudul.setText(judul);
        String deskripsi = info.getDeskripsi();
        String detail = info.getDetail();
        String runtime = info.getRuntime();
        String budget = info.getBudget();
        String revenue = info.getRevenue();
        int photo = info.getPhoto();
        //       Picasso.get().load(info.getPhoto()).fit().centerCrop().into(imgPhoto);
//        imgPhoto.setImageResource(photo);
        Glide.with(DetailTv.this)
                .load(photo)
                .into(imgPhoto);
        int collec = info.getCollect();
        Glide.with(DetailTv.this)
                .load(collec)
                .into(imgCollec);
        tvJudul.setText(judul);
        tvDeskripsi.setText(deskripsi);
        tvInfo.setText(detail);
        tvRuntime.setText(runtime);
        tvBudget.setText(revenue);
        tvRevenue.setText(budget);
    }
}
