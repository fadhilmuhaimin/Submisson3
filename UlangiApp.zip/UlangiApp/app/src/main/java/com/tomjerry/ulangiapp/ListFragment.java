package com.tomjerry.ulangiapp;

import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.tomjerry.ulangiapp.dummy.DetailMovie;

import java.util.ArrayList;

public class ListFragment extends Fragment implements ListMovieAdapter.OnDetailClick {
    private String[] dataName;
    private String[] dataDescription;
    private String[] dataDetail;
    private String[] dataRuntime;
    private String[] dataBudget;
    private String[] dataRevenue;
    private TypedArray dataPhoto;
    private RecyclerView rvMovies;
//    private ListMovieAdapter adapter;
    private ArrayList<Movie> list;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, container, false);
        rvMovies = view.findViewById(R.id.rv_film);
        rvMovies.setHasFixedSize(true);
        prepare();
        addItem();
        setListFilm();


      return view;
    }
//

//    @Override
//    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//        rvMovies = (RecyclerView) view.findViewById(R.id.rv_film);
//        setListFilm();
//    }



//    @Override
//    public void onCreate(@NonNull Bundle savedInstanceState) {
    private void addItem() {
       list = new ArrayList<>();
        for (int i = 0; i < dataName.length; i++) {
            Movie hero = new Movie();
            hero.setPhoto(dataPhoto.getResourceId(i, -1));
            hero.setName(dataName[i]);
            hero.setDeskripsi(dataDescription[i]);
            hero.setDetail(dataDetail[i]);
            hero.setRuntime(dataRuntime[i]);
            hero.setBudget(dataBudget[i]);
            hero.setRevenue(dataRevenue[i]);

            list.add(hero);
        }
    }

    private void prepare() {
        dataName = getResources().getStringArray(R.array.data_name);
        dataDescription = getResources().getStringArray(R.array.data_description);
        dataPhoto = getResources().obtainTypedArray(R.array.data_photo);
        dataDetail = getResources().getStringArray(R.array.data_details);
        dataRuntime = getResources().getStringArray(R.array.data_runtime);
        dataBudget = getResources().getStringArray(R.array.data_budget);
        dataRevenue = getResources().getStringArray(R.array.data_revenue);

    }
    private void setListFilm(){
        rvMovies.setLayoutManager(new LinearLayoutManager(getContext()));
        ListMovieAdapter listMovieAdapter  = new  ListMovieAdapter(getContext());
        listMovieAdapter.setListMovieAdapter(list);
        rvMovies.setAdapter(listMovieAdapter);
        listMovieAdapter.setOnDetailClick(this);
    }

    private void showSelectedMovie (Movie movie){
        Intent intent = new Intent(getActivity(), DetailMovie.class);
        intent.putExtra("extra_info",movie);
        startActivity(intent);
    }


    @Override
    public void onClick(Movie movie) {
        showSelectedMovie(movie);
    }
}
