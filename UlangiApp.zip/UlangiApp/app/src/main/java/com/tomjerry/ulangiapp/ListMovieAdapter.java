package com.tomjerry.ulangiapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;
import java.util.List;

public class ListMovieAdapter  extends RecyclerView.Adapter<ListMovieAdapter.ListViewHolder>{
    private ArrayList<Movie> listMovie;
    private Context context;
    private List<Movie> test;

    private OnDetailClick onDetailClick;

    private ArrayList<Movie> getListMovie(){
        return listMovie;
    }
    public ListMovieAdapter(Context context) {
        this.context = context;
    }

    public void setListMovieAdapter(ArrayList<Movie> listMovie) {

        this.listMovie = listMovie;
        ;
    }

    @Override
    public ListViewHolder onCreateViewHolder( ViewGroup viewGroup, int position) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_fragment, viewGroup, false);
        this.context = viewGroup.getContext();
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ListViewHolder holder, final int position) {
        final Movie movie = listMovie.get(position);
        Glide.with(holder.itemView.getContext())
                .load(movie.getPhoto())
//                .apply(new RequestOptions().override(55, 55))
                .into(holder.imgPhoto);
        holder.tvName.setText(movie.getName());
        holder.tvFrom.setText(movie.getDeskripsi());
        holder.view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onDetailClick.onClick(movie);
            }
        });
        holder.btnFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(holder.itemView.getContext(), "Favorit Kamu " + getListMovie().get(position).getName(),Toast.LENGTH_SHORT).show();
            }
        });
        holder.btnUnlike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(holder.itemView.getContext(),"Kamu Tidak Menyukai "+getListMovie().get(position).getName(),Toast.LENGTH_SHORT).show();
            }
        });
        holder.btnLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(holder.itemView.getContext(),"Kamu Menyukai "+getListMovie().get(position).getName(),Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return listMovie.size();
    }

    public class ListViewHolder extends RecyclerView.ViewHolder {
        ImageButton btnLike, btnUnlike,btnFavorite;
        ImageView imgPhoto;
        public View view;
        TextView tvName, tvFrom;
        public ListViewHolder( View itemView) {
            super(itemView);
            imgPhoto = itemView.findViewById(R.id.img_photo);
            tvName = itemView.findViewById(R.id.txt_name);
            tvFrom = itemView.findViewById(R.id.description);
            btnFavorite = itemView.findViewById(R.id.favorite);
            btnLike = itemView.findViewById(R.id.like);
            btnUnlike = itemView.findViewById(R.id.unlike);
            this.view = itemView;
        }
    }
    public interface OnDetailClick{
        void onClick(Movie movie);
    }

    public void  setOnDetailClick (OnDetailClick onDetailClick){
        this.onDetailClick = onDetailClick;
    }
}
