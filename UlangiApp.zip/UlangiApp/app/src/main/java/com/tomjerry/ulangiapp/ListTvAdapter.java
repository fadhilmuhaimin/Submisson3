package com.tomjerry.ulangiapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;


import java.util.ArrayList;


public class ListTvAdapter  extends RecyclerView.Adapter<ListTvAdapter.ListViewHolder> {
    public void setListTvAdapter(ArrayList<Tv> listTv) {
        this.listTv = listTv;
    }

    private ArrayList<Tv> getListTv(){
        return listTv;
    }
    public ListTvAdapter(Context context) {
        this.context = context;
    }

    private ArrayList<Tv> listTv;
    private Context context;
    private OnDetailClick onDetailClick;



    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int position) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_fragment, viewGroup, false);
        this.context = viewGroup.getContext();
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ListViewHolder holder, final int position) {
        final Tv tv = listTv.get(position);
        Glide.with(holder.itemView.getContext())
                .load(tv.getPhoto())
                .into(holder.imgPhoto);
        holder.tvName.setText(tv.getName());
        holder.tvFrom.setText(tv.getDeskripsi());
        holder.view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onDetailClick.onClick(tv);
            }
        });
        holder.btnFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(holder.itemView.getContext(), "Favorit Kamu " + getListTv().get(position).getName(),Toast.LENGTH_SHORT).show();
            }
        });
        holder.btnUnlike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(holder.itemView.getContext(),"Kamu Tidak Menyukai "+getListTv().get(position).getName(),Toast.LENGTH_SHORT).show();
            }
        });
        holder.btnLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(holder.itemView.getContext(),"Kamu Menyukai "+ getListTv().get(position).getName(),Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return listTv.size();
    }

    public class ListViewHolder extends RecyclerView.ViewHolder {
        ImageView imgPhoto;
        TextView tvName, tvFrom;
        ImageButton btnLike, btnUnlike,btnFavorite;
        public View view;
        public ListViewHolder(@NonNull View itemView) {
            super(itemView);
            imgPhoto = itemView.findViewById(R.id.img_photo);
            tvName = itemView.findViewById(R.id.txt_name);
            tvFrom = itemView.findViewById(R.id.description);
            btnFavorite = itemView.findViewById(R.id.favorite);
            btnLike = itemView.findViewById(R.id.like);
            btnUnlike = itemView.findViewById(R.id.unlike);
            this.view = itemView;
            this.view = itemView;

        }
    }
    public interface OnDetailClick{
        void onClick(Tv tv);
    }
    public void setOnDetailClick(OnDetailClick onDetailClick){
        this.onDetailClick = onDetailClick;
    }
}

