package com.tomjerry.ulangiapp;

import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class TvFragment extends Fragment implements ListTvAdapter.OnDetailClick {
    private String[] dataName;
    private String[] dataDescription;
    private String[] dataDetail;
    private String[] dataRuntime;
    private String[] dataBudget;
    private String[] dataRevenue;
    private TypedArray dataPhoto,dataCollec;
    private RecyclerView rvTv;
    private ListTvAdapter adapter;
    private ArrayList<Tv> list;
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, container, false);
        rvTv = view.findViewById(R.id.rv_film);
        rvTv.setHasFixedSize(true);
        prepare();
        addItem();
        setListTv();
        return view;
    }

    private void addItem() {
        list = new ArrayList<>();
        for (int i = 0; i < dataName.length; i++) {
            Tv hero = new Tv();
            hero.setPhoto(dataPhoto.getResourceId(i, -1));
            hero.setName(dataName[i]);
            hero.setDeskripsi(dataDescription[i]);
            hero.setDetail(dataDetail[i]);
            hero.setRuntime(dataRuntime[i]);
            hero.setBudget(dataBudget[i]);
            hero.setRevenue(dataRevenue[i]);
            hero.setCollect(dataCollec.getResourceId(i,-1));
            list.add(hero);
        }
    }

    private void prepare() {
        dataName = getResources().getStringArray(R.array.name_tv);
        dataDescription = getResources().getStringArray(R.array.genre_tv);
        dataPhoto = getResources().obtainTypedArray(R.array.photo_tv);
        dataDetail = getResources().getStringArray(R.array.details_tv);
        dataRuntime = getResources().getStringArray(R.array.runtime_tv);
        dataBudget = getResources().getStringArray(R.array.languange_tv);
        dataRevenue = getResources().getStringArray(R.array.type_tv);
        dataCollec = getResources().obtainTypedArray(R.array.arc_tv);
    }
    private void setListTv(){
        rvTv.setLayoutManager(new LinearLayoutManager(getContext()));
        ListTvAdapter listTvAdapter  = new  ListTvAdapter(getContext());
        listTvAdapter.setListTvAdapter(list);
        rvTv.setAdapter(listTvAdapter);
        listTvAdapter.setOnDetailClick(this);
    }

    private void showSelectedTv(Tv tv){
        Intent intent = new Intent(getActivity(),DetailTv.class);
        intent.putExtra("extra_info",tv);
        startActivity(intent);

    }
    @Override
    public void onClick(Tv tv) {
        showSelectedTv(tv);
    }
}
