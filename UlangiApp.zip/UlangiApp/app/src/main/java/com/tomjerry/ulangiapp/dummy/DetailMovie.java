package com.tomjerry.ulangiapp.dummy;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.tomjerry.ulangiapp.Movie;
import com.tomjerry.ulangiapp.R;

public class DetailMovie extends AppCompatActivity {
    public static final String EXTRA_INFO = "extra_info";
    TextView tvJudul,tvDeskripsi,tvInfo,tvRuntime,tvBudget,tvRevenue;
    ImageView imgPhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_movie);
        tvJudul = findViewById(R.id.title);
        tvDeskripsi = findViewById(R.id.textView8);
        tvInfo = findViewById(R.id.description);
        tvRuntime = findViewById(R.id.runtimee);
        tvBudget = findViewById(R.id.budget);
        tvRevenue = findViewById(R.id.revenuee);
        imgPhoto = findViewById(R.id.imageView);



        Movie info = getIntent().getParcelableExtra(EXTRA_INFO);
        String judul = info.getName();
      //  tvJudul.setText(judul);
        String deskripsi = info.getDeskripsi();
        String detail = info.getDetail();
        String runtime = info.getRuntime();
        String budget = info.getBudget();
        String revenue = info.getRevenue();
        int photo = info.getPhoto();
        //       Picasso.get().load(info.getPhoto()).fit().centerCrop().into(imgPhoto);
//        imgPhoto.setImageResource(photo);
        Glide.with(DetailMovie.this)
                .load(photo)
                .into(imgPhoto);
       tvJudul.setText(judul);
        tvDeskripsi.setText(deskripsi);
        tvInfo.setText(detail);
        tvRuntime.setText(runtime);
        tvBudget.setText(budget);
        tvRevenue.setText(revenue);
    }
}
